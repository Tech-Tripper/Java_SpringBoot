package com.techtalentsouth.TechTalentBlog.BlogPost;

import org.springframework.data.repository.CrudRepository;

//The naming of the repository don't  as long as the arguments that are parsed to the 
//repository match e.g BloPOst and long type has to match what your blog post is defined to
// whereby the id is Long type
public interface BlogPostRepository extends CrudRepository<BlogPost, Long>{

}
